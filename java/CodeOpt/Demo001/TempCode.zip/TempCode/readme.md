### 业务描述
> App调用 后台getInBill或getOutBill 接口获取单据信息，后端要根据前端App的要求返回相关数据
> 后端查询结果 经过convert转换器 转换成VO对象传递给App
> convert转换器 是各种单据（门店入库单，门店出库单，中心入库单，中心出库单等）共用的一套转换器，随着业务的扩展，会支持各种单据
> 所以convert的的if判断会越来越多，代码越来越冗余，而且每次修改都可能会影响其他单据，不符合开闭原则
> 故对此进行了优化 消除了所有if判断和魔法值等

### 目录结构
aold包 是优化之前的代码
anew包 是优化之后的代码
common包 是共用代码，包括 service，entity等没有参考价值的代码

### 新旧 controller 对比
新controller去掉了魔法值 "billType", "getOrgan"

### 新旧 convert 对比
1: 新convert 利用枚举 优化了“设置单据状态”的业务代码
2: 新convert 没有任何if判断，并且不会因为业务的扩展导致代码越来越冗余，并且完全遵循开闭原则

### 可通过 Test类 测试两个convert的输出
