package com.common.aznno;

public @interface RequestMapping {
    String name() default "";
}
