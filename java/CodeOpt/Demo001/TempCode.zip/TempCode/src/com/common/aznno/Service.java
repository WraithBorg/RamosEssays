package com.common.aznno;

public @interface Service {
}
