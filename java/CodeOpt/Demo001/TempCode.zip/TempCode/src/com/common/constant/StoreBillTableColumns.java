package com.common.constant;

public class StoreBillTableColumns {
    public static final String billType = "billType";
    public static final String sendOrgan = "sendOrgan";
    public static final String getOrgan = "getOrgan";

}
