package com.common.aznno;

public @interface Controller {
}
