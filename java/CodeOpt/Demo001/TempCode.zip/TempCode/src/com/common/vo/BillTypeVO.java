package com.common.vo;

/**
 * 单据类型展现层
 */
public class BillTypeVO extends BaseEntityVO {
    @Override
    public String toString() {
        return "BusinessTypeDTO{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", pinYin='" + pinYin + '\'' +
                ", code='" + code + '\'' +
                '}';
    }
}
