package com.common.service;

import com.common.aznno.Service;
import com.common.entity.BillType;
import com.common.entity.Organ;
import com.common.entity.StoreBill;

import java.util.Date;

@Service
public class StoreBillService {
    public static StoreBill get(String id, String[] strings) {
//        StoreBill bill = hsmBillService.getOneBill(billId, new String[]{"billType", "getOrgan", "sendOrgan"});
        BillType billBusType = new BillType();
        billBusType.setId("0430");
        billBusType.setName("入库单");
        Organ getOrgan = new Organ();
        getOrgan.setId("001");
        getOrgan.setName("西青店");
     /*   Organ sendOrgan = new Organ();
        sendOrgan.setId("002");
        sendOrgan.setName("天津配送中心");*/
        //
        StoreBill storeBill = new StoreBill();
        storeBill.setGetOrgan(getOrgan);
//        storeBill.setSendOrgan(sendOrgan);
        storeBill.setBillType(billBusType);
        storeBill.setBillState(1);
        storeBill.setBusDate(new Date());
        return storeBill;
    }
}
