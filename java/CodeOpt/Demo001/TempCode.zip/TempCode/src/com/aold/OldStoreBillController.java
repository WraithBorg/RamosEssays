package com.aold;


import com.common.aznno.Controller;
import com.common.aznno.RequestMapping;
import com.common.entity.StoreBill;
import com.common.service.StoreBillService;
import com.common.vo.StoreBillVO;

@Controller
public class OldStoreBillController {
    /**
     * 查询入库单据信息
     */
    @RequestMapping(name = "getInBill")
    public static StoreBillVO getInBill(String billId) {
        // 查询数据 并 转换成VO给前端显示
        // storeBillService.get 方法是封装的hibernate查询方法
        // billType（单据类型）和getOrgan（收货机构） 是懒加载对象
        StoreBill bill = StoreBillService.get(billId, new String[]{"billType", "getOrgan"});
        return OldBillConverter.from(bill);
    }
    /**
     * 查询出库单据信息
     */
    @RequestMapping(name = "getOutBill")
    public static StoreBillVO getOutBill(String billId) {
        // 查询数据 并 转换成VO给前端显示
        StoreBill bill = StoreBillService.get(billId, new String[]{"billType", "sendOrgan"});
        return OldBillConverter.from(bill);
    }
}
