package com.aold;

import com.common.aznno.Component;
import com.common.entity.StoreBill;
import com.common.utils.DDateUtil;
import com.common.vo.BillTypeVO;
import com.common.vo.ShopVO;
import com.common.vo.StoreBillVO;

@Component
public class OldBillConverter {
    /**
     * 将单据 StoreBill 转换成 StoreBillVO(前端展示数据结构)
     * // 1:不符合 开放封闭原则，当程序需要改变时，应该通过拓展的方式来实现变化，而不是通过修改已有代码来实现
     * // 2:随着单据类型 和 条件分支的增加，会变得更冗余，方法体会更长
     */
    public static StoreBillVO from(StoreBill billDB) {
        StoreBillVO billDTO = new StoreBillVO();
        //      单据类型
        BillTypeVO billTypeVO = null;
        // TODO 为什么会有 （if ！= null）判断，因为 billType，sendOrgan和getOrgan等对象是 billDB（单据对象）的懒加载属性，
        //  而不同业务或不同单据类型 情况下，这些懒加载对象可能为空
        if (billDB.getBillType() != null) {
            billTypeVO = new BillTypeVO();
            billTypeVO.setId(billDB.getBillType().getId());
            billTypeVO.setName(billDB.getBillType().getName());
        }
        //      ## 发货机构
        ShopVO rdcDTO = null;
        if (billDB.getSendOrgan() != null) {
            rdcDTO = new ShopVO(billDB.getSendOrgan().getId(), billDB.getSendOrgan().getName(), billDB.getSendOrgan().getCode());
        }
        //      ## 收货机构
        ShopVO inShopDTO = null;
        if (billDB.getGetOrgan() != null) {
            inShopDTO = new ShopVO(billDB.getGetOrgan().getId(), billDB.getGetOrgan().getName(), billDB.getGetOrgan().getCode());
        }
        // 设置单据日期
        billDTO.setWorkDate(DDateUtil.formYMdHms(billDB.getBusDate()));
        // 设置单据状态
        if (billDB.getBillState() == 1) {//1：待提交；2：待审核； 3：已审核
            billDTO.setBillStateFlag("0");
            billDTO.setBillStateFlagName("待提交");
        } else if (billDB.getBillState() == 2) {
            billDTO.setBillStateFlag("2");
            billDTO.setBillStateFlagName("待审核");
        } else {
            billDTO.setBillStateFlag("1");
            billDTO.setBillStateFlagName("已审核");
        }
        //
        billDTO.setInShopDTO(inShopDTO);
        billDTO.setBillBusType(billTypeVO);
        billDTO.setRdcDTO(rdcDTO);
        // 设置其他通用属性 比如金额 数量
        return billDTO;
    }
}
