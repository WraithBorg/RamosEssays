package com;

import com.anew.NewStoreBillController;
import com.aold.OldStoreBillController;

public class Test {
    public static void main(String[] args) {
        System.out.println(NewStoreBillController.getInBill("1111"));
        System.out.println(OldStoreBillController.getInBill("1111"));
    }
}
