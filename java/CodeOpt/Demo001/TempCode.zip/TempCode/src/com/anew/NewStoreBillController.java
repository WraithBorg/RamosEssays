package com.anew;


import com.common.aznno.Controller;
import com.common.aznno.RequestMapping;
import com.common.entity.StoreBill;
import com.common.service.StoreBillService;
import com.common.vo.StoreBillVO;

@Controller
public class NewStoreBillController {
    /**
     * 查询入库单据信息 新写法
     */
    @RequestMapping(name = "getInBill")
    public static StoreBillVO getInBill(String billId) {
        // 通过链式编程 设定装配那些属性，然后查询数据 并转换成VO
        HsmBFuncUtils installProps = new HsmBFuncUtils().billType().getOrgan();
        StoreBill bill = StoreBillService.get(billId, installProps.props());
        return NewBillConverter.form(bill, installProps);
    }
    /**
     * 查询出库单据信息 新写法
     */
    @RequestMapping(name = "getOutBill")
    public static StoreBillVO getOutBill(String billId) {
        // 通过链式编程 设定装配那些属性，然后查询数据 并转换成VO
        HsmBFuncUtils installProps = new HsmBFuncUtils().billType().sendOrgan();
        StoreBill bill = StoreBillService.get(billId, installProps.props());
        return NewBillConverter.form(bill, installProps);
    }
}
