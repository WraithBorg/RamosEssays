package com.anew;


import com.common.aznno.Component;
import com.common.entity.StoreBill;
import com.common.eum.BillStateEnum;
import com.common.utils.DDateUtil;
import com.common.vo.StoreBillVO;

import java.util.function.BiFunction;

@Component
public class NewBillConverter {
    /**
     * 将单据 StoreBill 转换成 StoreBillVO
     */
    public static StoreBillVO form(StoreBill bill, HsmBFuncUtils hsmBFunc) {
        StoreBillVO dto = generateBaseProps(bill);// 装配单据通用的基本属性
        install(bill, hsmBFunc, dto);// 自动根据不同情况，装配不同属性
        return dto;
    }
    /**
     * 组装基本属性，这个可能会随着业务的扩展 会有微小变动，不过改动范围已经控制在最小范围
     */
    private static StoreBillVO generateBaseProps(StoreBill billDB) {
        StoreBillVO billDTO = new StoreBillVO();
        billDTO.setId(billDB.getId());
        billDTO.setWorkDate(DDateUtil.formYMdHms(billDB.getBusDate()));// 设置单据日期
        BillStateEnum stateEnum = BillStateEnum.getEnm(billDB.getBillState());// 设置单据状态
        billDTO.setBillStateFlag(stateEnum.fVal());
        billDTO.setBillStateFlagName(stateEnum.fName());
        // 设置其他通用属性 比如金额 数量
        return billDTO;
    }
    /**
     * 根据不同情况，组装vo对象, 这个方法不会在有任何修改
     */
    private static void install(StoreBill bill, HsmBFuncUtils hsmBFunc, StoreBillVO dto) {
        for (BiFunction<StoreBill, StoreBillVO, StoreBillVO> fun : hsmBFunc.li()) {
            fun.apply(bill, dto);
        }
    }
}
