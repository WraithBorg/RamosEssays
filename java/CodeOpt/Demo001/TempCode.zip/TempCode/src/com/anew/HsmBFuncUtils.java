package com.anew;


import com.common.constant.StoreBillTableColumns;
import com.common.entity.StoreBill;
import com.common.vo.BillTypeVO;
import com.common.vo.ShopVO;
import com.common.vo.StoreBillVO;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;

/**
 * 自定义单据属性装配器
 */
public class HsmBFuncUtils {
    /************************************* Constructor *************************************/
    private List<BiFunction<StoreBill, StoreBillVO, StoreBillVO>> li;
    private List<String> props;
    public HsmBFuncUtils() {
        this.props = new ArrayList<>();
        this.li = new ArrayList<>();
    }
    public List<BiFunction<StoreBill, StoreBillVO, StoreBillVO>> li() {
        return li;
    }
    public String[] props() {
        return props.toArray(new String[]{});
    }
    /************************************* Props *************************************/
    // TODO 如果业务更加复杂的话，可以将 下面的方法剥离出去形成单独的类
    public HsmBFuncUtils billType() {// 单据类型 适配器
        BiFunction<StoreBill, StoreBillVO, StoreBillVO> func = (v1, v2) -> {
            BillTypeVO businessTypeDTO = new BillTypeVO();
            businessTypeDTO.setId(v1.getBillType().getId());
            businessTypeDTO.setName(v1.getBillType().getName());
            v2.setBillBusType(businessTypeDTO);
            return v2;
        };
        li.add(func);
        props.add(StoreBillTableColumns.billType);
        return this;
    }
    public HsmBFuncUtils sendOrgan() { // 发货机构 适配器
        BiFunction<StoreBill, StoreBillVO, StoreBillVO> func = (v1, v2) -> {
            ShopVO rdcDTO = new ShopVO(v1.getSendOrgan().getId(), v1.getSendOrgan().getName(), v1.getSendOrgan().getCode());
            v2.setRdcDTO(rdcDTO);
            return v2;
        };
        li.add(func);
        props.add(StoreBillTableColumns.sendOrgan);
        return this;
    }
    public HsmBFuncUtils getOrgan() {// 收货机构 适配器
        BiFunction<StoreBill, StoreBillVO, StoreBillVO> func = (v1, v2) -> {
            ShopVO inShopDTO = new ShopVO(v1.getGetOrgan().getId(), v1.getGetOrgan().getName(), v1.getGetOrgan().getCode());
            v2.setInShopDTO(inShopDTO);
            return v2;
        };
        li.add(func);
        props.add(StoreBillTableColumns.getOrgan);
        return this;
    }
}
